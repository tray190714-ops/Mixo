# MIXO — version web prête à déployer

MIXO est un prototype de marketplace sociale : acheter, vendre, découvrir et partager.

## Déploiement

Cette version est un site statique. Elle peut être déployée sur n'importe quel hébergeur statique compatible avec HTML/CSS/JavaScript.

### Structure

- `index.html` — application web
- `assets/` — dossier prévu pour les images, icônes et autres ressources

## Important

Les comptes, annonces, messages, favoris et publications sont encore simulés côté navigateur.
Pour une vraie version publique, il faudra connecter :
- une base de données
- une authentification
- un stockage d'images/vidéos
- une messagerie persistante
- une modération
- des règles et documents légaux
- une solution de paiement si les transactions sont gérées dans MIXO

La partie adoption d'animaux devra être soumise à des règles de modération et à la réglementation applicable avant ouverture au public.
