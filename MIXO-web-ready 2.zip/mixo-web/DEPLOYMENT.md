# Checklist avant mise en ligne

- [ ] Choisir l'hébergeur
- [ ] Connecter un domaine
- [ ] Remplacer les données de démonstration par une base de données
- [ ] Ajouter authentification
- [ ] Ajouter stockage sécurisé des images/vidéos
- [ ] Ajouter modération et signalement
- [ ] Ajouter CGU, politique de confidentialité et mentions légales
- [ ] Vérifier les règles spécifiques aux annonces d'animaux
- [ ] Tester mobile, tablette et ordinateur
- [ ] Tester les formulaires et messages
- [ ] Mettre en place sauvegardes et sécurité
